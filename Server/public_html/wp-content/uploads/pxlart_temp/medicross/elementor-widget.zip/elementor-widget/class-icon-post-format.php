<?php

class IconPostFormat_Widget extends Pxltheme_Core_Widget_Base{
    protected $name = 'icon_post_format';
    protected $title = 'Case Icon Post Format';
    protected $icon = 'eicon-cart-medium';
    protected $categories = array( 'pxltheme-core' );
    protected $params = '{"sections":[]}';
    protected $styles = array(  );
    protected $scripts = array(  );
}